import { combineReducers } from 'redux';

import employee from './employee';

const reducers = {
    employee
};

export default combineReducers(reducers);
