/**
 * @param {number} x - x
 * @param {number} y - y
 */
export function add(x, y) {
    return x + y
}

// add(1, '2')