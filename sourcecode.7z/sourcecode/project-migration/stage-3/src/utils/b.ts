export function sub(x: number, y: number) {
    return x - y
}