import EmployeeQuery from './components/EmployeeQuery.vue';
export default EmployeeQuery;