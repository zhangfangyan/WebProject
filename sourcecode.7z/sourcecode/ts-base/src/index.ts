let hello: string = 'Hello TypeScript'
document.querySelectorAll('.app')[0].innerHTML = hello
