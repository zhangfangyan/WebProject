// exports === module.exports
// 导出多个变量
// module.exports = {}
exports.c = 3
exports.d = 4