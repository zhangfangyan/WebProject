import Server = require('../src/server')

let c = new Server()

// do test