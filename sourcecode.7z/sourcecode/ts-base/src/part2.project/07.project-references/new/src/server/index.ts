import { getTime } from '../common'

console.log(`Server Time: ${getTime()}`)

class Server {}

export = Server